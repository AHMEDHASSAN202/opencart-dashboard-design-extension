<?php
/**
 * Created by PhpStorm.
 * User: AQSSA
 */
// Heading
$_['heading_title']    = 'Dashboard Design';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified dashboard design module!';
$_['text_edit']        = 'Edit Dashboard Design Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify dashboard design module!';


$_['status_required'] = 'Status is Required';
